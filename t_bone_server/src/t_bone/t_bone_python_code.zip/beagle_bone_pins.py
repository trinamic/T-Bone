__author__ = 'marcus'

pwm_config = [
    {
        'temp': 'P9_39',
        'out': 'P9_14',
        'current_input': 1,
        'high_power': True
    },
    {
        'temp': 'P9_40',
        'out': 'P9_16',
        'current_input': 0,
        'high_power': True
    },
    {
        'temp': 'P9_37',
        'out': 'P8_19',
        'high_power': False
    }
]